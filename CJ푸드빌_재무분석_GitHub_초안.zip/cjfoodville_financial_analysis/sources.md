# Sources

1. CJ푸드빌 공식 홈페이지 결산공고
   - https://www.cjfoodville.co.kr/story/finance.asp
   - 2024년 연결 재무상태표 세부 수치 확인에 사용

2. CJ Corp. 2025 Annual Report / 사업보고서
   - 2026-03-18 공시
   - CJ푸드빌 2025/2024/2023 연결 매출실적 확인
   - https://financialfilings.com/filings/cj-corp/annual-report/2026/32972906/

3. 보조 확인자료
   - CJ푸드빌 2025년 요약 재무수치(매출, 영업이익, 순이익, 자산, 부채, 자본)
   - https://www.openbizdata.com/cjfoodville/

4. 계산 기준
   - 첨부파일: `재무제표 및 재무비율 실무 가이드`
   - 금액과 비율을 함께 보고 추세를 분석
   - ROA/ROE는 평균 자산·평균 자본을 사용
   - 부채비율 = 총부채 / 자본총계
